/*
CST 223 - Concepts of Programming Languages
Lab1 - Part a
Logan Wright

Purpose:  A "Hello World!" application.
*/

#include <stdio.h>

int main()
{
	printf("Hello World!\n");
	return 0;
}
